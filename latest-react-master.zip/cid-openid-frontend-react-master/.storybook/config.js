import {
  configure,
  setAddon,
  addDecorator,
  addParameters
} from "@storybook/react";
import JSXAddon from "storybook-addon-jsx";
import { withKnobs } from "@storybook/addon-knobs";
import { INITIAL_VIEWPORTS } from "@storybook/addon-viewport";
import "bootstrap/dist/css/bootstrap.min.css";
import "../src/assets/scss/VFApp.scss";

addParameters({
  options: {
    isFullscreen: false,
    panelPosition: "right",
    showPanel: false,
    isToolshown: true
  },
  viewport: {
    viewports: INITIAL_VIEWPORTS
  }
});

addDecorator(withKnobs);
setAddon(JSXAddon);

const req = require.context("../src", true, /.stories.js$/);

function loadStories() {
  require("../src/stories/Welcome.stories");
  req.keys().forEach(file => req(file));
}

configure(loadStories, module);
