import React from "react";
import { storiesOf } from "@storybook/react";

import VFNotification from "../components/shared/VFNotification";

storiesOf("/VFNotification", module).add("VFNotification", () => (
  <VFNotification />
));
