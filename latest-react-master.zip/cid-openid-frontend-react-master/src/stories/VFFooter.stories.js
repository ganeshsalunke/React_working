import React from "react";
import { storiesOf } from "@storybook/react";
import VFFooter from "../components/shared/VFFooter";

storiesOf("/Layout", module).add("VFFooter", () => <VFFooter />);
