import React from "react";
import { storiesOf } from "@storybook/react";

const styles = {
  fontWeight: "600",
  margin: "0px",
  padding: "0px",
  fontSize: "30px",
  textAlign: "center"
};

const Readme = () => (
  <div>
    <div>
      <h2 style={styles}>ID Storybook UI</h2>
    </div>
  </div>
);

storiesOf("Welcome", module)
  .addParameters({
    info: {
      // Make a default for all stories in this book,
      inline: true, // where the components are inlined
      styles: {
        header: {
          h1: {
            color: "red" // and the headers of the sections are red.
          }
        }
      }
    }
  })
  .add("README", Readme);
