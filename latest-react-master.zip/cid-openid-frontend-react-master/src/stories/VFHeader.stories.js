import React from "react";
import { storiesOf } from "@storybook/react";
import VFHeader from "../components/shared/VFHeader";

storiesOf("/Layout", module).add("VFHeader", () => <VFHeader />);
