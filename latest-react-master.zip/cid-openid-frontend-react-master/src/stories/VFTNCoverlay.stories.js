import React from "react";
import { storiesOf } from "@storybook/react";

import VFTnCoverlay from "../components/overlays/VFTnCoverlay";

storiesOf("/VFOverlays", module).add("Terms & Conditions", () => (
  <VFTnCoverlay />
));
