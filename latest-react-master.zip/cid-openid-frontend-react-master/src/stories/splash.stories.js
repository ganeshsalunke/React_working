import React from "react";
import { storiesOf } from "@storybook/react";

import VFSplash from "../components/shared/VFSplash";

storiesOf("/VFSplash", module).add("VFSplash", () => <VFSplash />);
