import React, { useState, useEffect } from "react";
import "./assets/scss/VFApp.scss";
import axios from "axios";
import VFSplash from "./components/shared/VFSplash";
import VFHeader from "./components/shared/VFHeader";
import VFFooter from "./components/shared/VFFooter";
import Validate from "./components/validate/Validate";
import VFNotification from "./components/shared/VFNotification";

function VFApp() {
  const [contextData, setContextData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setErrorState] = useState(null);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then(res => {
        setContextData(res.data);
        setIsLoading(true);
      })
      .catch(err => {
        setErrorState(err.message);
        setIsLoading(true);
      });
  }, []);

  return (
    <div className="d-flex flex-column h-100">
      <VFHeader />
      <Validate />
      <VFFooter />
    </div>
  );
}

export default VFApp;
