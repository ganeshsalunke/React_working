import React from "react";
import "./VFTnCoverlay.scss";

class VFTnCoverlay extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            style : {
                "display" : "block"
            }
        };
        this.openOverlay = this.openOverlay.bind(this);
        this.closeOverlay = this.closeOverlay.bind(this);
    }

    componentDidMount() {
        document.addEventListener("click", this.closeOverlay);
    }

    componentWillUnmount() {
        document.removeEventListener("click", this.closeOverlay);
    }

    openOverlay() {
        const style = { "display" : "block" };
        this.setState({ style });
        document.addEventListener("click", this.closeOverlay);
    }

    closeOverlay() {
        document.removeEventListener("click", this.closeOverlay);
        const style = { "display" : "none" };
        this.setState({ style });
    }

render() {
    return (
        <div className="container" style={this.state.style}>
        <div className="tnc-overlay">
                <div className="tnc-overlay__content">
                    <header>
                        <h4>Vodafone ID Terms and Conditions</h4>
                        <span className="close" onClick={this.closeOverlay}></span>
                    </header>
                    <div className="tnc-overlay-main">
                        <div className="description">
                            <div className="title">1. Your acceptence of these Terms</div>
                            Welcome to Vodafone ID (powered by Mobile Connect) provided by Vodafone Limited, registered in England with company number 1471587, whose registered office is at Vodafone House, The Connection, Newbury, Berkshire RG14 2FN (“Vodafone”, also “we”, “us” or “our”).<br/> <br/> These terms and conditions (the Terms) apply to your use of Vodafone ID.  By using Vodafone ID, you accept the following Terms.<br/><br/>
                            <div className="title">2. Your personal information</div>
                            How we collect and use your information generally is explained in our Privacy Policy which can be found at <a href="https://www.vodafone.co.uk/privacy" target="_blank">https://www.vodafone.co.uk/privacy</a>.<br/><br/>                                      
                            <div className="title">3. Vodafone ID</div>
                            Your Vodafone ID is your “Vodafone identity” and it will help you to securely access any Vodafone apps and services (such as Vodafone offers, Vodafone Secure Net or the V by Vodafone app) and/or third party apps and services (<b>Third Party Apps</b>) by using the same login details. <br/><br/> Upon launching a Vodafone app or Third Party App, you may be prompted to enter your mobile number and give permission to Vodafone to send a SMS message (for example, containing a one-time PIN to your device) for authentication. Additional details such as an email address, may be required for further identification purposes if you are not an existing Vodafone customer at the time of first using the Vodafone ID feature. <br/> <br/> You will be able to build your Vodafone ID by setting additional methods of authentication via your Vodafone ID online page or through the Vodafone Start App (<b>Start App</b>) where you can also set a PIN and biometrics (such as your device fingerprint) or receive Vodafone ID notifications. You can subsequently manage your security methods via your online Vodafone ID page or through the Start App.<br/><br/>Depending on the level of security, different Vodafone apps or Third Party Apps may require different methods of authentication (such as your email address) to access their apps/services with your Vodafone ID. If you do not have the required method of authentication set up, you will be prompted to do so before you can access the app/service with your Vodafone ID.<br/><br/> Vodafone ID will be compliant with GSMA Mobile Connect ID solutions.<br/><br/>
                            <div className="title">4. Third Party Apps and Services</div>
                            You may use Vodafone ID to access Third Party Apps. These services may have their own legal terms, privacy policies and eligibility requirements. Please read their terms and conditions to ensure you are familiar with how Third Party Apps work and how your data may be used.  You understand and agree that we are not responsible or liable for the behaviour, features or content of any Third Party Apps.<br/><br/>                                      
                            <div className="title">5. Rights and licence</div>
                            We grant you a non-exclusive, non-transferable licence to use Vodafone ID on your mobile device for your own personal non-commercial use only.<br/> <br/> We and our licensors own all proprietary rights in the Start App.  You will not have any right to the Start App apart from the right to use the Start App in line with these terms.<br/><br/>                                      
                            <div className="title">6. Your responsibilities</div>
                            You will need to check that Vodafone ID is compatible with your device prior to use.<br/><br/>                                      
                            <div className="title">7. Cost</div>
                            Vodafone ID is provided to you free of charge (save for any applicable data charges referred to below).<br/> <br/> Unless you are using a Wi-Fi connection, you will be charged according to your mobile plan for the use of data.<br/><br/>                                      
                            <div className="title">8. What we are not responsible for</div>
                            You must notify us immediately of any breach of security or unauthorised use of your mobile phone.<br/> <br/> We are not responsible for any errors or omissions in relation to Third Party Apps.<br/><br/> Neither we nor our licensors warrant that Vodafone ID will meet your requirements or that the operation of Vodafone ID will be uninterrupted or error free. To the extent permitted by law we and our licensors disclaim and exclude all warranties, representations, conditions and other terms of any kind, express or implied by law or otherwise.<br/><br/> Nothing in these terms affects any legal rights you have as a consumer. For more information about your legal rights contact your local consumer advisory body.<br/><br/>                                      
                            <div className="title">9. Security</div>
                            You are responsible for safeguarding any PINS or passwords that you use to access this service and are responsible for any use of your Vodafone ID, whether or not you authorised that activity. You should immediately notify us of any unauthorised use of your account.<br/> <br/> Vodafone ID is for the use of authorised users only in accordance with Vodafone security policies and procedures. Individuals using this device without authorisation or in excess of their authority are subject to sanctioning procedures by Vodafone authorities and/or law enforcement officials. Vodafone will not be responsible for any misuse or personal use of any kind, in its information systems, and reserves the right for monitoring systems usage to control abusive situations or security policy violations. <br/> <br/> We reserve the right to suspend, place a “read-only” restriction upon, archive or terminate anyone’s account at any time, with or without cause, and with or without notice.  Cause for such action include: (a) violations of these Terms or any other policies or guidelines; (b) a request by you to cancel or terminate your account; (c) a request and/or order from law enforcement, a judicial body, or other government agency; (d) unexpected technical or security issues or problems; (e) your participation in fraudulent or illegal activities; or (f) failure to pay any fees owed by you.<br/><br/>                                      
                            <div className="title">10. Changing the terms</div>
                            We reserve the right to revise these Terms from time to time and the most current version will always be posted on our website.<br/><br/>                                      
                            <div className="title">11. General terms</div>
                            You agree that we may transfer our rights and obligations under these terms to another Vodafone group company and we may allow another person to perform any of our obligations under these terms on our behalf.  If we transfer our rights and obligations to any other third party, we will let you know. If any of these terms cannot be enforced by any court or other authority, we will delete it from these terms and it will not affect the rest of the terms. We may send you notices by email, text, post or on our website.<br/> <br/> These terms and the provision of Vodafone ID will be governed by the laws of England and Wales. Any disputes will be dealt with by the courts of England and Wales.<br/><br/>                                      
                            <div className="title">12. Support</div>
                            We hope you enjoy using Vodafone ID. If you have any problem, you can contact us directly through the website Vodafone HQ, The Connection, Newbury, Berkshire, RG14 2FN, Registered in England No 1471587.<br/><br/>         
                        </div>
                    </div>
                    <footer>
                        <p>25<sup>th</sup> May 2018</p>
                    </footer>
                </div>
            </div>
        </div>
    );
    
}
}
export default VFTnCoverlay;
