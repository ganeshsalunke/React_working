import React from "react";

function VFFooter() {
  return (
    <footer className="footer mt-auto py-3 text-white">
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-8">
            <ul className="nav">
              <li className="navbar-text">
                <a href="#" id="termsOfUse">
                  Terms and conditions
                </a>
              </li>
              <li className="navbar-text">
                <a href="#" id="termsOfUse">
                  Privacy Policy
                </a>
              </li>
              <li className="navbar-text">
                <a href="#" id="termsOfUse">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
          <div className="col-md-4 text-copyright">
            <span>@ 2019 Vodafone</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
export default VFFooter;
