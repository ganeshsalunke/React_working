import React from "react";

function VFHeader() {
  return (
    <header>
      {/* Fixed navbar */}
      <nav className="navbar navbar-expand-md navbar-dark fixed-top navbar-vf">
        <div className="container-fluid">
          <div className="logo_wrapper">
            <div className="logo logo_vf"></div>
          </div>
        </div>
      </nav>
    </header>
  );
}
export default VFHeader;
