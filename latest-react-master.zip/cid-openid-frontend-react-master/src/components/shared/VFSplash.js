import React from "react";
import "./VFSplash.scss";

function VFSplash() {
  return (
    <div className="vf-splash">
      <div className="vf-splash-spinner"></div>
    </div>
  );
}
export default VFSplash;
