import React from "react";
import "./VFSplash.scss";

function VFNotification() {
  return (
    <div className="vf-splash">
      <div className="vf-splash-spinner"></div>
      <p className="notification-message">
        Something went wrong. Please try again!
      </p>
    </div>
  );
}
export default VFNotification;
