import React, { useState } from "react";

function Validate() {
  const [count, setCount] = useState(0);
  return <div className="main-wrapper"></div>;
}

export default Validate;
