import React from "react";
import { render } from "@testing-library/react";
import VFApp from "./VFApp";
it("renders welcome message", () => {
  const { getByText } = render(<VFApp />);
  expect(getByText("Learn React")).toBeInTheDocument();
});
