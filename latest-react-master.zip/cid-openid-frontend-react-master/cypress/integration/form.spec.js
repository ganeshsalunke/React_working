describe("Form", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("it focuses the input", () => {
    cy.focused().should("have.class", "form-control");
  });

  it("accepts input", () => {
    const input = "Learn about Cypress";
    cy.get(".form-control")
      .type(input)
      .should("have.value", input);
  });
});

describe("Request", () => {
  it("displays random users from API", () => {
    cy.request("https://jsonplaceholder.typicode.com/users").should(
      response => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.length(10);
        expect(response).to.have.property("headers");
        expect(response).to.have.property("duration");
      }
    );
  });
});
