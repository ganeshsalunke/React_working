describe("Cypress", () => {
  it("should assert that true is equal to true", () => {
    expect(true).to.equal(true);
  });
});
